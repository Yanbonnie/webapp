
const app = getApp();
const { key } = app.globalData;
import { URL, WXREQ } from './util';
module.exports = {
    'comData': {
        'phoneList':[1,2],
        'operState':false,
        'zanData':{
            context:'您今天已经为商家点过赞了，你可购买以下产品为商家增加人气',
            btnArr:[{
                txt:'鲜花',
                price:1
            },{
                txt:'壁画',
                price:6
            },{
                txt:'花圈',
                price:18
            }],
            id:null
        }
    },
    'methodsArr':{
        //获取电话列表
        getPhoneList(e){
            const { id } = e.currentTarget.dataset;
            return new Promise((resolve,reject)=>{
                console.log(id)
                WXREQ('GET',URL['getTel'],{
                    key,
                    id
                },res=>{
                    if(res.status == 0){
                        resolve(res.data);
                    }else{
                        wx.showToast({
                            title: '获取联系方式失败',
                            icon:'none'
                        })
                    }
                })
            })
        },
        //点击拨打电话
        toggleActionsheet(e) {
            wx.showLoading({
                title: '获取中...',
            })
            this.getPhoneList(e).then(res => {
                wx.hideLoading();
                let telArr = [];
                for (let i = 0; i < res.tel.length; i++) {
                    telArr.push({
                        name: res.tel[i],
                        className: 'action-class',
                        loading: false
                    })
                }
                this.setData({
                    'baseActionsheet.actions': telArr,
                    'baseActionsheet.show': true
                })
            });
        },//选择电话号码
        _handleZanActionsheetBtnClick(res) {
            const { componentId, index } = res.currentTarget.dataset;
            const { actions } = this.data.baseActionsheet;
            console.log(actions[index].name)
            wx.makePhoneCall({
                phoneNumber: actions[index].name
            })
        },
        //弹出层点击消失
        _handleZanActionsheetMaskClick() {
            this.setData({
                'baseActionsheet.show': false
            })
        },
        //点击查看查单
        lookMenu(e) {
            const { id } = e.currentTarget.dataset;
            wx.showLoading({
                title: '加载中...',
            })
            WXREQ('GET', URL['getPic'], {
                key,
                unionid: app.globalData.userInfo.unionid,
                id
            }, res => {
                if (res.status == 0) {
                    const { data } = res;
                    let urls = [];
                    for (let i = 0; i < data.length; i++) {
                        urls.push(data[i].pic)
                    }
                    //预览照片
                    wx.previewImage({
                        urls: urls, // 需要预览的图片http链接列表
                        success: res => {
                            wx.hideLoading()
                        }
                    })
                } else {
                    wx.showToast({
                        title: res.msg,
                        icon: 'none',
                        mask: true
                    })
                }
            })
        }, 
        //到达详情页
        goDetail(e) {
            const { id } = e.currentTarget.dataset;
            wx.navigateTo({
                url: `/pages/detail/detail?id=${id}`,
            })
        },  
        //点赞
        zanHandle(e){
            const { id, is_praise } = e.currentTarget.dataset;
            if (app.globalData.is_pay_praise == 1){  //支付点赞
                this.postPraise(id);
                this.setData({
                    operState:true,   
                    'zanData.id':id                 
                })
            }else{
                if(is_praise == 1) return;
                this.postPraise(id);
            }
        },
        //商家点赞
        postPraise(id){
            WXREQ('POST', URL['postPraise'],{
                key,
                unionid:app.globalData.userInfo.unionid,
                id
            },res=>{
                if(res.status == 0){
                    this.getConfig();
                }else{
                    wx.showToast({
                        title: '点赞失败',
                        icon:'none'
                    })
                }
            })
        },
        //商家支付点赞
        payMoneyHandle(options){
            console.log(options)
            let money = options.detail;
            let id = this.data.zanData.id;
            wx.showLoading({
                title: '加载中...',
                mask:true
            })
            WXREQ('POST', URL['payPraise'],{
                key,
                id,
                unionid:app.globalData.userInfo.unionid,
                money:price
            },res=>{

            })
        },
        /**
     * 用户点击右上角分享
     */
        onShareAppMessage: function () {
            return {
                'title': '食在南塘',
                'path': '/pages/enter/enter',
                'imageUrl': '/assets/images/picture.jpeg',
                success: res => {
                    // 转发成功

                }
            }
        }
    }
}